@echo off
setlocal enabledelayedexpansion

set "INSTALL_DIR=%USERPROFILE%\g57-program-files"
set "ZIP_FILE=g57-local-assistant-be-release.zip"
set "URL=https://github.com/jorgexxx/g57-copilot-local-public/raw/master/g57-local-assistant-be-release.zip"
set "SHORTCUT_NAME=g57-copilot-local.bat"

echo Stopping processes on port 30101...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr :30101') do taskkill /PID %%a /F

echo Cleaning old files...
if exist "%INSTALL_DIR%" rmdir /S /Q "%INSTALL_DIR%"
if exist "%ZIP_FILE%" del "%ZIP_FILE%"

echo Downloading new ZIP...
powershell -Command "Invoke-WebRequest -Uri '%URL%' -OutFile '%ZIP_FILE%'"

echo Unzipping...
powershell -Command "Expand-Archive -Path '%ZIP_FILE%' -DestinationPath '%USERPROFILE%' -Force"

if not exist "%INSTALL_DIR%" (
    echo Error: Unzip failed.
    goto :error
)

echo Creating desktop shortcut...
set "DESKTOP_PATH=%USERPROFILE%\Desktop"
(
echo @echo off
echo call %%USERPROFILE%%\AppData\Roaming\nvm\nvm.exe
echo cd /d "%INSTALL_DIR%" ^&^& npm run pro
echo pause
) > "%DESKTOP_PATH%\%SHORTCUT_NAME%"

echo Installation completed. Shortcut created on desktop.

set /p RUN_NOW="Do you want to run the process now? (Y/N): "
if /i "%RUN_NOW%"=="Y" (
    call "%DESKTOP_PATH%\%SHORTCUT_NAME%"
) else (
    echo You can run the process later using the desktop shortcut.
)

goto :end

:error
echo Installation failed.

:end
pause