@echo off
setlocal enabledelayedexpansion

:: Check if NVM is already installed
where nvm >nul 2>&1
if %errorLevel% equ 0 (
    echo NVM is already installed
    echo Current versions:
    nvm --version
    node --version
    npm --version
    pause
    exit /b 0
)

:: Check if running as administrator
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Please run as Administrator
    pause
    exit /b 1
)

:: Set download URLs
set "NVM_URL=https://github.com/coreybutler/nvm-windows/releases/download/1.1.11/nvm-setup.exe"
set "INSTALL_DIR=%TEMP%\nvm-install"

:: Create temp directory
mkdir "%INSTALL_DIR%" 2>nul

:: Download NVM installer
echo Downloading NVM installer...
powershell -Command "(New-Object Net.WebClient).DownloadFile('%NVM_URL%', '%INSTALL_DIR%\nvm-setup.exe')"

:: Install NVM silently
echo Installing NVM...
start /wait "" "%INSTALL_DIR%\nvm-setup.exe" /SILENT

:: Refresh environment variables
call refreshenv.cmd 2>nul
if %ERRORLEVEL% neq 0 (
    set "PATH=%PATH%;%ProgramFiles%\nvm;%ProgramFiles%\nodejs"
)

:: Install latest LTS Node.js
echo Installing Node.js LTS...
nvm install lts
nvm use lts

:: Cleanup
rmdir /s /q "%INSTALL_DIR%"

:: Verify installation
echo Verifying installation...
where nvm >nul 2>&1 || (echo NVM installation failed && exit /b 1)
where node >nul 2>&1 || (echo Node installation failed && exit /b 1)
where npm >nul 2>&1 || (echo NPM installation failed && exit /b 1)

:: Show versions
echo Installation successful! Current versions:
nvm --version
node --version
npm --version

pause