#!/bin/bash

RELEASE_ZIP="g57-local-assistant-be-release.zip"
INSTALLER_ZIP="g57-copilot-installer-ubuntu.zip"
PROGRAM_FOLDER="gutil-scripts"
INSTALL_DIR="$HOME/$PROGRAM_FOLDER"
URL="https://github.com/jorgexxx/g57-copilot-local-public/raw/master/$RELEASE_ZIP"
SHORTCUT_NAME="g57-copilot-local.sh"
DESKTOP_PATH=$(xdg-user-dir DESKTOP)

stop_processes() {
    echo "Stopping processes on port 30101..."
    kill -9 $(lsof -t -i:30101 -sTCP:LISTEN)
}

clean_old_files() {
    echo "Cleaning old files..."
    [ -d "$INSTALL_DIR" ] && rm -rf "$INSTALL_DIR"
    [ -f "$RELEASE_ZIP" ] && rm "$RELEASE_ZIP"
}

download_zip() {
    echo "Downloading new ZIP..."
    wget -O "$RELEASE_ZIP" "$URL"
}

unzip_file() {
    echo "Unzipping..."
    unzip -o "$RELEASE_ZIP" -d "$HOME"
}

verify_installation() {
    [ ! -d "$INSTALL_DIR" ] && { echo "Error: Unzip failed."; exit 1; }
}

create_shortcut() {
    [ ! -d "$DESKTOP_PATH" ] && { echo "Desktop folder not found."; exit 1; }
    cat > "$DESKTOP_PATH/$SHORTCUT_NAME" << EOL
#!/bin/bash
export NVM_DIR="\$HOME/.nvm"
[ -s "\$NVM_DIR/nvm.sh" ] && \. "\$NVM_DIR/nvm.sh"
[ -s "\$NVM_DIR/bash_completion" ] && \. "\$NVM_DIR/bash_completion"
cd "$INSTALL_DIR" && npm run pro
exec \$SHELL
EOL
    chmod +x "$DESKTOP_PATH/$SHORTCUT_NAME"
}

cleanup() {
    echo "Cleaning up..."
    [ -f "$(dirname "$0")/$RELEASE_ZIP" ] && rm "$(dirname "$0")/$RELEASE_ZIP"
    [ -f "$(dirname "$0")/$INSTALLER_ZIP" ] && rm "$(dirname "$0")/$INSTALLER_ZIP"
    [ -d "$(dirname "$0")/$PROGRAM_FOLDER" ] && rm -rf "$(dirname "$0")/$PROGRAM_FOLDER"
}

stop_processes
clean_old_files
download_zip
unzip_file
verify_installation
create_shortcut
echo "Installation completed. Shortcut created on desktop."

cleanup

read -p "Do you want to run the application now? (y/n): " RUN_NOW
[ "$RUN_NOW" = "y" -o "$RUN_NOW" = "Y" ] && bash "$DESKTOP_PATH/$SHORTCUT_NAME"

echo "Done."

# Keep the terminal window open
exec $SHELL