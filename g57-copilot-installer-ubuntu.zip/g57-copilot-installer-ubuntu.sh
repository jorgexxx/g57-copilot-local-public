#!/bin/bash

# Define the installation directory
INSTALL_DIR="$HOME/g57-program-files"
ZIP_FILE="g57-local-assistant-be-release.zip"
URL="https://github.com/jorgexxx/g57-copilot-local-public/raw/master/g57-local-assistant-be-release.zip"
SHORTCUT_NAME="g57-copilot-local.sh"

# Function to stop processes on port 30101
stop_processes() {
    echo "Stopping processes on port 30101..."
    kill -9 $(lsof -t -i:30101 -sTCP:LISTEN)
}

# Function to clean old files
clean_old_files() {
    echo "Cleaning old files..."
    [ -d "$INSTALL_DIR" ] && rm -rf "$INSTALL_DIR"
    [ -f "$ZIP_FILE" ] && rm "$ZIP_FILE"
}

# Function to download the ZIP file
download_zip() {
    echo "Downloading new ZIP..."
    wget -O "$ZIP_FILE" "$URL"
}

# Function to unzip the file
unzip_file() {
    echo "Unzipping..."
    unzip -o "$ZIP_FILE" -d "$HOME"
}

# Function to verify installation
verify_installation() {
    if [ ! -d "$INSTALL_DIR" ]; then
        echo "Error: Unzip failed."
        exit 1
    fi
}

# Function to create desktop shortcut
create_shortcut() {
    DESKTOP_PATH=$(xdg-user-dir DESKTOP)
    if [ ! -d "$DESKTOP_PATH" ]; then
        echo "Desktop folder not found."
        exit 1
    fi

    DESKTOP_SCRIPT="$DESKTOP_PATH/$SHORTCUT_NAME"
    cat > "$DESKTOP_SCRIPT" << EOL
#!/bin/bash
export NVM_DIR="\$HOME/.nvm"
[ -s "\$NVM_DIR/nvm.sh" ] && \. "\$NVM_DIR/nvm.sh"
[ -s "\$NVM_DIR/bash_completion" ] && \. "\$NVM_DIR/bash_completion"
cd "$INSTALL_DIR" && npm run pro
exec \$SHELL
EOL

    chmod +x "$DESKTOP_SCRIPT"
}

# Main script execution
stop_processes
clean_old_files
download_zip
unzip_file
verify_installation
create_shortcut

echo "Installation completed. Shortcut created on desktop."